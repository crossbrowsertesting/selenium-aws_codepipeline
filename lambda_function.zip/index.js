'use strict';

exports.handler = (event, context, callback) => {
    var webdriver = require('selenium-webdriver');
    var remoteHub = 'http://hub.crossbrowsertesting.com:80/wd/hub';
    var sessionId = null;
    var message = null;

    var caps = {
    'name': 'Login Form Example',
    'build': '1.0',
    'browserName': 'Chrome',
    'platform': 'Windows 10',
    'record_video': 'true',
    'username' : process.env.CBT_USERNAME,
    'password' : process.env.CBT_AUTHKEY
    };
  
    console.log('Connection to the CrossBrowserTesting remote server');
    async function login(){
    try{
        var driver = new webdriver.Builder()
                .usingServer(remoteHub)
                .withCapabilities(caps)
                .build();

        console.log('Waiting on the browser to be launched and the session to start');

        await driver.getSession().then(function(session){
            sessionId = session.id_; //need for API calls
            console.log('Session ID: ', sessionId); 
            console.log('See your test run at: https://app.crossbrowsertesting.com/selenium/' + sessionId);
        });

        //load your URL
        await driver.get(event.url);
      
        await driver.findElement(webdriver.By.id("username")).sendKeys("tester@crossbrowsertesting.com");

        //send keys to element to enter text
        await driver.findElement(webdriver.By.xpath("//*[@type=\"password\"]")).sendKeys("test123");

        //click the archive button
        await driver.findElement(webdriver.By.css("button[type=submit]")).click();

        //wait on logged in message
        await driver.wait(webdriver.until.elementLocated(webdriver.By.id("logged-in-message")), 10000);
        message = await driver.findElement(webdriver.By.id("logged-in-message")).getText();
        console.log(message);
        
        //quit the driver
        await driver.quit();

        }
        catch(e){
            webdriverErrorHandler(e, driver);
        }

    }

    login();

    //general error catching function
    function webdriverErrorHandler(err, driver){
        console.error('There was an unhandled exception! ' + err.message);

        //if we had a session, end it and mark failed
        if (driver && sessionId){
            driver.quit();
        }
    }

};
