'use strict';

var AWS = require('aws-sdk');
var webdriver = require('selenium-webdriver');

exports.handler = (event, context, callback) => {
    var codepipeline = new AWS.CodePipeline();
    
    // Retrieve the Job ID from the Lambda action
    var jobId = event["CodePipeline.job"].id;
    
    // Retrieve the value of UserParameters from the Lambda action configuration in AWS CodePipeline
    var url = event["CodePipeline.job"].data.actionConfiguration.configuration.UserParameters; 
    
      // Notify AWS CodePipeline of a successful job
    var putJobSuccess = function(message) {
        var params = {
            jobId: jobId
        };
        codepipeline.putJobSuccessResult(params, function(err, data) {
            if(err) {
                context.fail(err);      
            } else {
                context.succeed(message);      
            }
        });
    };
    
     // Notify AWS CodePipeline of a failed job
    var putJobFailure = function(message) {
        var params = {
            jobId: jobId,
            failureDetails: {
                message: JSON.stringify(message),
                type: 'JobFailed',
                externalExecutionId: context.invokeid
            }
        };
        codepipeline.putJobFailureResult(params, function(err, data) {
            context.fail(message); 
            if(err) {
                console.error(err.message);      
            }
        });
    };
    
    var remoteHub = 'http://hub.crossbrowsertesting.com:80/wd/hub';
    var sessionId = null;
    var message = null;

    var caps = {
    'name': 'Login Form Example',
    'build': '1.0',
    'browserName': 'Chrome',
    'platform': 'Windows 10',
    'record_video': 'true',
    'username' : process.env.CBT_USERNAME,
    'password' : process.env.CBT_AUTHKEY
    };
  
    console.log('Connection to the CrossBrowserTesting remote server');
    async function login(){
    try{
        var driver = new webdriver.Builder()
                .usingServer(remoteHub)
                .withCapabilities(caps)
                .build();

        console.log('Waiting on the browser to be launched and the session to start');

        await driver.getSession().then(function(session){
            sessionId = session.id_; //need for API calls
            console.log('Session ID: ', sessionId); 
            console.log('See your test run at: https://app.crossbrowsertesting.com/selenium/' + sessionId);
        });

        //load your URL
        await driver.get(url);
      
        await driver.findElement(webdriver.By.id("username")).sendKeys("tester@crossbrowsertesting.com");

        //send keys to element to enter text
        await driver.findElement(webdriver.By.xpath("//*[@type=\"password\"]")).sendKeys("test123");

        //click the archive button
        await driver.findElement(webdriver.By.css("button[type=submit]")).click();

        //wait on logged in message
        await driver.wait(webdriver.until.elementLocated(webdriver.By.id("logged-in-message")), 10000);
        message = await driver.findElement(webdriver.By.id("logged-in-message")).getText();
        console.log(message);
        
        //quit the driver
        await driver.quit();
        putJobSuccess("Tests passed.");

        }
        catch(e){
            webdriverErrorHandler(e, driver);
        }

    }

    login();

    //general error catching function
    function webdriverErrorHandler(err, driver){
        console.error('There was an unhandled exception! ' + err.message);

        //if we had a session, end it and mark failed
        if (driver && sessionId){
            driver.quit();
        }
        putJobFailure(err);
    }

};
